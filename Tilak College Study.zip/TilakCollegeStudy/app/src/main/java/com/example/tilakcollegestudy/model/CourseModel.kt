package com.example.tilakcollegestudy.model

data class CourseModel(val courseName: String)