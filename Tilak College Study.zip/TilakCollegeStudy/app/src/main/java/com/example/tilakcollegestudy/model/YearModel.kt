package com.example.tilakcollegestudy.model

data class YearModel(val yearName: String)