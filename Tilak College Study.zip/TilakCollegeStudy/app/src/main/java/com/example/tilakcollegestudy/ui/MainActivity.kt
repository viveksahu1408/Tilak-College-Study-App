package com.example.tilakcollegestudy.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tilakcollegestudy.R
import com.example.tilakcollegestudy.adapters.CourseAdapter
import com.example.tilakcollegestudy.data.repository.AuthViewModel
import com.example.tilakcollegestudy.databinding.ActivityMainBinding
import com.example.tilakcollegestudy.model.CourseModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private val viewModel: AuthViewModel by viewModels()

    private val courseList = listOf(
        CourseModel("BA"),
        CourseModel("BSc"),
        CourseModel("BCom"),
        CourseModel("MA"),
        CourseModel("MSc"),
        CourseModel("MCom"),
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = findViewById(R.id.courseRecyclerView)
        recyclerView.layoutManager = GridLayoutManager(this,2)


      //  binding.tv.text = "welcom to tilak college study app"
     binding.tv.setOnClickListener {
         viewModel.logout()
         startActivity(Intent(this,LoginActivity::class.java))
     }
        val adapter = CourseAdapter(courseList) { selectedCourse ->
           val intent = Intent(this, YearSelectionActivity::class.java)
            intent.putExtra("course", selectedCourse)
            startActivity(intent)
        }

        recyclerView.adapter = adapter


    }
}