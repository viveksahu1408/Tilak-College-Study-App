package com.example.tilakcollegestudy.model

data class PdfModel(
    val title: String = "",
    val url: String = ""
)