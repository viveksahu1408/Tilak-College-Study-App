package com.example.tilakcollegestudy.model

data class SubjectModel(val subjectName: String)